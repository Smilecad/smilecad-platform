import { NextResponse } from 'next/server'
import { getAuthenticatedServerUser } from '@/lib/auth-server'
import { supabaseAdmin } from '@/lib/supabase/admin'

type RouteContext = {
  params: Promise<{ id: string }>
}

function normalizeStringArray(value: unknown): string[] {
  if (Array.isArray(value)) {
    return value.filter((item): item is string => typeof item === 'string')
  }

  if (typeof value === 'string') {
    const trimmed = value.trim()
    if (!trimmed) return []

    try {
      const parsed = JSON.parse(trimmed)
      if (Array.isArray(parsed)) {
        return parsed.filter((item): item is string => typeof item === 'string')
      }
    } catch {
      return [trimmed]
    }

    return [trimmed]
  }

  return []
}

export async function POST(request: Request, context: RouteContext) {
  try {
    const { id } = await context.params
    const { user, profile } = await getAuthenticatedServerUser(request)

    const body = await request.json().catch(() => ({}))
    const design_file_names = normalizeStringArray(body.design_file_names)
    const design_file_paths = normalizeStringArray(body.design_file_paths)

    if (design_file_names.length !== design_file_paths.length) {
      return NextResponse.json(
        { error: '파일 이름과 파일 경로 수가 일치하지 않습니다.' },
        { status: 400 }
      )
    }

    const { data: order, error: orderError } = await supabaseAdmin
      .from('orders')
      .select('id, user_id, is_canceled, status')
      .eq('id', id)
      .single()

    if (orderError || !order) {
      return NextResponse.json(
        { error: '주문 정보를 찾을 수 없습니다.' },
        { status: 404 }
      )
    }

    const isAdmin = profile.role === 'admin'
    const isOwnerClinic = order.user_id === user.id

    if (!isAdmin && !isOwnerClinic) {
      return NextResponse.json(
        { error: '디자인 파일을 수정할 권한이 없습니다.' },
        { status: 403 }
      )
    }

    if (order.is_canceled) {
      return NextResponse.json(
        { error: '취소된 주문에는 파일을 업로드할 수 없습니다.' },
        { status: 400 }
      )
    }

    const nextStatus =
      profile.role === 'clinic' && order.status === '수정 요청 중'
        ? '주문 재접수'
        : order.status

    const { error: updateError } = await supabaseAdmin
      .from('orders')
      .update({
        design_file_names,
        design_file_paths,
        admin_revision_requested: nextStatus === '주문 재접수' ? false : order.status === '수정 요청 중',
        status: nextStatus,
      })
      .eq('id', id)

    if (updateError) {
      return NextResponse.json(
        { error: updateError.message },
        { status: 500 }
      )
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    const message =
      error instanceof Error ? error.message : '디자인 파일 저장 중 오류가 발생했습니다.'

    return NextResponse.json({ error: message }, { status: 500 })
  }

  
}